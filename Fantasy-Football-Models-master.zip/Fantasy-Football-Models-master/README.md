# Fantasy-Football-Models
Beating my friends with data science


To use the model
- Download "Fantasy Football Analysis v2"
- install.package(<INSERT ALL NECESSARY PACKAGES>)
- Run the code
- Insert who's been drafted thus far, and who's on your team
- Run the 'OPTIMIZER ALERT WEE WOO' section again to get updated predictions


sorry for the mess. gl and ill clean it up if people care
